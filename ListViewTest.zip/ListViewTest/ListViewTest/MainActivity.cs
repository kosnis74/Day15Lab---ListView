﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace ListViewTest
{
    [Activity(Label = "ListViewTest", MainLauncher = true)]
    public class MainActivity : ListActivity
    {

        string[] items;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            //SetContentView(Resource.Layout.Main);


            items = new string[] { "Vegetables","Fruits","Flower Buds",
                         "Legumes","Bulbs","Tubers" };
            ListAdapter = new ArrayAdapter(this,
                                    Android.Resource.Layout.SimpleListItem1, items);


        }

        protected override void OnListItemClick(ListView l, View v, int position, long id)
        {
            base.OnListItemClick(l, v, position, id);

            // notice the use of "Toast" to display an alert in Android
            Toast.MakeText(this, items[position], ToastLength.Short).Show();
        }

    }
}

