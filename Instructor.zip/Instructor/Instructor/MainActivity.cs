﻿using Android.App;
using Android.Widget;
using Android.OS;
using MU.IT;

namespace Instructor
{
    [Activity(Label = "Instructor", MainLauncher = true)]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            var instructorList = FindViewById<ListView>(Resource.Id.instructorListView);

            instructorList.Adapter = new ArrayAdapter(this,
                                                        Android.Resource.Layout.SimpleListItem1,
                                                        InstructorData.Instructors);
        }

        void OnItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            var instructor = InstructorData.Instructors[e.Position];

            var dialog = new AlertDialog.Builder(this);
            dialog.SetMessage(instructor.Name);
            dialog.SetNeutralButton("OK", delegate { });
            dialog.Show();
        }
    }
}

